//
// Copyright (C) 2006-2011 Christoph Sommer <christoph.sommer@uibk.ac.at>
//
// Documentation for these modules is at http://veins.car2x.org/
//
// SPDX-License-Identifier: GPL-2.0-or-later
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

//车辆行为控制，主要目的是演示如何在车载网络中使用和处理消息。该模块实现了一个简单的车辆通信协议，其中车辆会定期广播其位置信息，并且可以处理接收到的其他车辆的位置信息

#include "veins/modules/application/traci/TraCIDemo11p.h"

#include "veins/modules/application/traci/TraCIDemo11pMessage_m.h"

using namespace veins;

Define_Module(veins::TraCIDemo11p);

//对于每个模块，initialize 方法会被调用多次，每个阶段（stage）分别对应不同的初始化任务
void TraCIDemo11p::initialize(int stage)
{
    DemoBaseApplLayer::initialize(stage); //调用父类 DemoBaseApplLayer 的 initialize 方法
    if (stage == 0) { //阶段 0 通常用于设置模块的内部状态和参数
        sentMessage = false; //表示这个模块尚未发送任何消息
        lastDroveAt = simTime(); //simTime()用于读取当前仿真时间，表示最后一次驾驶的时间
        currentSubscribedServiceId = -1; // 表示当前没有订阅任何服务
    }
}

//WSA:WAVE Service Advertisement，廣播封包來通知鄰近的其他通訊設備關於服務的資訊，這些資訊主要包含服務的種類與進行服務所使用的服務頻道
//onWSA 方法的作用是处理收到的 WSA（Wave Service Advertisement）服务广告消息，当收到一个 WSA 消息时，如果当前没有订阅任何服务，或者当前提供的服务与 WSA 消息中的服务不同，则会改变服务频道，并订阅 WSA 消息中的服务
void TraCIDemo11p::onWSA(DemoServiceAdvertisment* wsa)
{
    // // 检查当前是否已经订阅了某个服务。值为 -1，则表示当前没有订阅任何服务
    if (currentSubscribedServiceId == -1) {
        //改变当前的服务频道
        mac->changeServiceChannel(static_cast<Channel>(wsa->getTargetChannel()));
        // 将 WSA 消息中的 PSID （Provider Service Identifier）设置为当前订阅的服务 ID
        currentSubscribedServiceId = wsa->getPsid();
        // 检查当前提供的服务 ID 是否与 WSA 消息中的 PSID 相同
        if (currentOfferedServiceId != wsa->getPsid()) { //發現不同
            // 停止当前的服务
            stopService();
            // 启动新的服务
            startService(static_cast<Channel>(wsa->getTargetChannel()), wsa->getPsid(), "Mirrored Traffic Service");
        }
    }
}

//onWSM 方法的作用是处理收到的 WSM（Wave Short Message）消息，当收到一个 WSM 时，如果这是第一次收到消息，则会发送一条新的消息；同时，如果路线 ID 不以 ':' 开头，还会改变路线
void TraCIDemo11p::onWSM(BaseFrame1609_4* frame)
{
    TraCIDemo11pMessage* wsm = check_and_cast<TraCIDemo11pMessage*>(frame);

    //表示车辆接收到了一个消息时在 OMNeT++ 的 GUI 中改变模块的颜色
    findHost()->getDisplayString().setTagArg("i", 1, "green");
    // 检查当前的路线 ID 是否以 ':' 开头。如果不是，就调用 traciVehicle->changeRoute 方法改变路线
    if (mobility->getRoadId()[0] != ':') traciVehicle->changeRoute(wsm->getDemoData(), 9999);
    if (!sentMessage) {
        sentMessage = true;
        // repeat the received traffic update once in 2 seconds plus some random delay
        wsm->setSenderAddress(myId); // 设置消息的发送者地址
        wsm->setSerial(3);  // 设置消息的发送者序列号
        scheduleAt(simTime() + 2 + uniform(0.01, 0.2), wsm->dup());
    }
}

// 用于处理自消息，到一个 TraCIDemo11pMessage 时，会发送一个复制的消息，然后增加消息的序列号，如果序列号大于或等于3，则停止服务并删除这条消息；否则，安排一个事件，在未来的某个时间再次发送这条消息。对于不是 TraCIDemo11pMessage 的消息，将其交给父类处理。
void TraCIDemo11p::handleSelfMsg(cMessage* msg)
{
    if (TraCIDemo11pMessage* wsm = dynamic_cast<TraCIDemo11pMessage*>(msg)) {
        // send this message on the service channel until the counter is 3 or higher.
        // this code only runs when channel switching is enabled
        sendDown(wsm->dup());
        wsm->setSerial(wsm->getSerial() + 1);
        if (wsm->getSerial() >= 3) {
            // stop service advertisements
            stopService();
            delete (wsm);
        }
        else {
            scheduleAt(simTime() + 1, wsm);
        }
    }
    else {
        DemoBaseApplLayer::handleSelfMsg(msg);
    }
}


// 位置更新时被调用，当位置更新时，根据车辆的速度和是否已经发送过消息来决定是否需要发送一个新的消息，以及怎么发送这个消息
void TraCIDemo11p::handlePositionUpdate(cObject* obj)
{
    DemoBaseApplLayer::handlePositionUpdate(obj);

    // stopped for for at least 10s?
    if (mobility->getSpeed() < 1) {
        if (simTime() - lastDroveAt >= 10 && sentMessage == false) {
            findHost()->getDisplayString().setTagArg("i", 1, "red");
            sentMessage = true;

            TraCIDemo11pMessage* wsm = new TraCIDemo11pMessage();
            populateWSM(wsm);
            wsm->setDemoData(mobility->getRoadId().c_str()); //设置消息内容为当前的路线 ID

            // host is standing still due to crash
            if (dataOnSch) {
                startService(Channel::sch2, 42, "Traffic Information Service");
                // started service and server advertising, schedule message to self to send later
                scheduleAt(computeAsynchronousSendingTime(1, ChannelType::service), wsm);
            }
            else {
                // send right away on CCH, because channel switching is disabled
                sendDown(wsm);  // 发送消息
            }
        }
    }
    else {
        lastDroveAt = simTime();
    }
}
