//
// Generated file, do not edit! Created by nedtool 5.6 from veins/modules/application/traci/BeaconRSU.msg.
//

// Disable warnings about unused variables, empty switch stmts, etc:
#ifdef _MSC_VER
#  pragma warning(disable:4101)
#  pragma warning(disable:4065)
#endif

#if defined(__clang__)
#  pragma clang diagnostic ignored "-Wshadow"
#  pragma clang diagnostic ignored "-Wconversion"
#  pragma clang diagnostic ignored "-Wunused-parameter"
#  pragma clang diagnostic ignored "-Wc++98-compat"
#  pragma clang diagnostic ignored "-Wunreachable-code-break"
#  pragma clang diagnostic ignored "-Wold-style-cast"
#elif defined(__GNUC__)
#  pragma GCC diagnostic ignored "-Wshadow"
#  pragma GCC diagnostic ignored "-Wconversion"
#  pragma GCC diagnostic ignored "-Wunused-parameter"
#  pragma GCC diagnostic ignored "-Wold-style-cast"
#  pragma GCC diagnostic ignored "-Wsuggest-attribute=noreturn"
#  pragma GCC diagnostic ignored "-Wfloat-conversion"
#endif

#include <iostream>
#include <sstream>
#include <memory>
#include "BeaconRSU_m.h"

namespace omnetpp {

// Template pack/unpack rules. They are declared *after* a1l type-specific pack functions for multiple reasons.
// They are in the omnetpp namespace, to allow them to be found by argument-dependent lookup via the cCommBuffer argument

// Packing/unpacking an std::vector
template<typename T, typename A>
void doParsimPacking(omnetpp::cCommBuffer *buffer, const std::vector<T,A>& v)
{
    int n = v.size();
    doParsimPacking(buffer, n);
    for (int i = 0; i < n; i++)
        doParsimPacking(buffer, v[i]);
}

template<typename T, typename A>
void doParsimUnpacking(omnetpp::cCommBuffer *buffer, std::vector<T,A>& v)
{
    int n;
    doParsimUnpacking(buffer, n);
    v.resize(n);
    for (int i = 0; i < n; i++)
        doParsimUnpacking(buffer, v[i]);
}

// Packing/unpacking an std::list
template<typename T, typename A>
void doParsimPacking(omnetpp::cCommBuffer *buffer, const std::list<T,A>& l)
{
    doParsimPacking(buffer, (int)l.size());
    for (typename std::list<T,A>::const_iterator it = l.begin(); it != l.end(); ++it)
        doParsimPacking(buffer, (T&)*it);
}

template<typename T, typename A>
void doParsimUnpacking(omnetpp::cCommBuffer *buffer, std::list<T,A>& l)
{
    int n;
    doParsimUnpacking(buffer, n);
    for (int i = 0; i < n; i++) {
        l.push_back(T());
        doParsimUnpacking(buffer, l.back());
    }
}

// Packing/unpacking an std::set
template<typename T, typename Tr, typename A>
void doParsimPacking(omnetpp::cCommBuffer *buffer, const std::set<T,Tr,A>& s)
{
    doParsimPacking(buffer, (int)s.size());
    for (typename std::set<T,Tr,A>::const_iterator it = s.begin(); it != s.end(); ++it)
        doParsimPacking(buffer, *it);
}

template<typename T, typename Tr, typename A>
void doParsimUnpacking(omnetpp::cCommBuffer *buffer, std::set<T,Tr,A>& s)
{
    int n;
    doParsimUnpacking(buffer, n);
    for (int i = 0; i < n; i++) {
        T x;
        doParsimUnpacking(buffer, x);
        s.insert(x);
    }
}

// Packing/unpacking an std::map
template<typename K, typename V, typename Tr, typename A>
void doParsimPacking(omnetpp::cCommBuffer *buffer, const std::map<K,V,Tr,A>& m)
{
    doParsimPacking(buffer, (int)m.size());
    for (typename std::map<K,V,Tr,A>::const_iterator it = m.begin(); it != m.end(); ++it) {
        doParsimPacking(buffer, it->first);
        doParsimPacking(buffer, it->second);
    }
}

template<typename K, typename V, typename Tr, typename A>
void doParsimUnpacking(omnetpp::cCommBuffer *buffer, std::map<K,V,Tr,A>& m)
{
    int n;
    doParsimUnpacking(buffer, n);
    for (int i = 0; i < n; i++) {
        K k; V v;
        doParsimUnpacking(buffer, k);
        doParsimUnpacking(buffer, v);
        m[k] = v;
    }
}

// Default pack/unpack function for arrays
template<typename T>
void doParsimArrayPacking(omnetpp::cCommBuffer *b, const T *t, int n)
{
    for (int i = 0; i < n; i++)
        doParsimPacking(b, t[i]);
}

template<typename T>
void doParsimArrayUnpacking(omnetpp::cCommBuffer *b, T *t, int n)
{
    for (int i = 0; i < n; i++)
        doParsimUnpacking(b, t[i]);
}

// Default rule to prevent compiler from choosing base class' doParsimPacking() function
template<typename T>
void doParsimPacking(omnetpp::cCommBuffer *, const T& t)
{
    throw omnetpp::cRuntimeError("Parsim error: No doParsimPacking() function for type %s", omnetpp::opp_typename(typeid(t)));
}

template<typename T>
void doParsimUnpacking(omnetpp::cCommBuffer *, T& t)
{
    throw omnetpp::cRuntimeError("Parsim error: No doParsimUnpacking() function for type %s", omnetpp::opp_typename(typeid(t)));
}

}  // namespace omnetpp

namespace {
template <class T> inline
typename std::enable_if<std::is_polymorphic<T>::value && std::is_base_of<omnetpp::cObject,T>::value, void *>::type
toVoidPtr(T* t)
{
    return (void *)(static_cast<const omnetpp::cObject *>(t));
}

template <class T> inline
typename std::enable_if<std::is_polymorphic<T>::value && !std::is_base_of<omnetpp::cObject,T>::value, void *>::type
toVoidPtr(T* t)
{
    return (void *)dynamic_cast<const void *>(t);
}

template <class T> inline
typename std::enable_if<!std::is_polymorphic<T>::value, void *>::type
toVoidPtr(T* t)
{
    return (void *)static_cast<const void *>(t);
}

}

namespace veins {

// forward
template<typename T, typename A>
std::ostream& operator<<(std::ostream& out, const std::vector<T,A>& vec);

// Template rule to generate operator<< for shared_ptr<T>
template<typename T>
inline std::ostream& operator<<(std::ostream& out,const std::shared_ptr<T>& t) { return out << t.get(); }

// Template rule which fires if a struct or class doesn't have operator<<
template<typename T>
inline std::ostream& operator<<(std::ostream& out,const T&) {return out;}

// operator<< for std::vector<T>
template<typename T, typename A>
inline std::ostream& operator<<(std::ostream& out, const std::vector<T,A>& vec)
{
    out.put('{');
    for(typename std::vector<T,A>::const_iterator it = vec.begin(); it != vec.end(); ++it)
    {
        if (it != vec.begin()) {
            out.put(','); out.put(' ');
        }
        out << *it;
    }
    out.put('}');

    char buf[32];
    sprintf(buf, " (size=%u)", (unsigned int)vec.size());
    out.write(buf, strlen(buf));
    return out;
}

Register_Class(BeaconRSU)

BeaconRSU::BeaconRSU(const char *name, short kind) : ::veins::BaseFrame1609_4(name, kind)
{
}

BeaconRSU::BeaconRSU(const BeaconRSU& other) : ::veins::BaseFrame1609_4(other)
{
    copy(other);
}

BeaconRSU::~BeaconRSU()
{
}

BeaconRSU& BeaconRSU::operator=(const BeaconRSU& other)
{
    if (this == &other) return *this;
    ::veins::BaseFrame1609_4::operator=(other);
    copy(other);
    return *this;
}

void BeaconRSU::copy(const BeaconRSU& other)   //add
{
    this->RSUId = other.RSUId;
    for (size_t i = 0; i < 100; i++) {
        this->position[i] = other.position[i];
    }
    for (size_t i = 0; i < 100; i++) {
        this->beaconrate[i] = other.beaconrate[i];
    }
    this->myDemoData = other.myDemoData;
    this->slotpos = other.slotpos;
    this->timestamp = other.timestamp;
    this->nonce = other.nonce;
    this->token = other.token;
    this->linkagevalue = other.linkagevalue;
    this->fingerprint = other.fingerprint;
}

void BeaconRSU::parsimPack(omnetpp::cCommBuffer *b) const    //add
{
    ::veins::BaseFrame1609_4::parsimPack(b);
    doParsimPacking(b,this->RSUId);
    doParsimArrayPacking(b,this->position,100);
    doParsimArrayPacking(b,this->beaconrate,100);
    doParsimPacking(b,this->myDemoData);
    doParsimPacking(b,this->slotpos);
    doParsimPacking(b,this->timestamp);
    doParsimPacking(b,this->nonce);
    doParsimPacking(b,this->token);
    doParsimPacking(b,this->linkagevalue);
    doParsimPacking(b,this->fingerprint);
}

void BeaconRSU::parsimUnpack(omnetpp::cCommBuffer *b)    //add
{
    ::veins::BaseFrame1609_4::parsimUnpack(b);
    doParsimUnpacking(b,this->RSUId);
    doParsimArrayUnpacking(b,this->position,100);
    doParsimArrayUnpacking(b,this->beaconrate,100);
    doParsimUnpacking(b,this->myDemoData);
    doParsimUnpacking(b,this->slotpos);
    doParsimUnpacking(b,this->timestamp);
    doParsimUnpacking(b,this->nonce);
    doParsimUnpacking(b,this->token);
    doParsimUnpacking(b,this->linkagevalue);
    doParsimUnpacking(b,this->fingerprint);
}

int BeaconRSU::getRSUId() const
{
    return this->RSUId;
}

void BeaconRSU::setRSUId(int RSUId)
{
    this->RSUId = RSUId;
}

size_t BeaconRSU::getPositionArraySize() const
{
    return 100;
}

const Coord& BeaconRSU::getPosition(size_t k) const
{
    if (k >= 100) throw omnetpp::cRuntimeError("Array of size 100 indexed by %lu", (unsigned long)k);
    return this->position[k];
}

void BeaconRSU::setPosition(size_t k, const Coord& position)
{
    if (k >= 100) throw omnetpp::cRuntimeError("Array of size 100 indexed by %lu", (unsigned long)k);
    this->position[k] = position;
}

size_t BeaconRSU::getBeaconrateArraySize() const
{
    return 100;
}

double BeaconRSU::getBeaconrate(size_t k) const
{
    if (k >= 100) throw omnetpp::cRuntimeError("Array of size 100 indexed by %lu", (unsigned long)k);
    return this->beaconrate[k];
}

void BeaconRSU::setBeaconrate(size_t k, double beaconrate)
{
    if (k >= 100) throw omnetpp::cRuntimeError("Array of size 100 indexed by %lu", (unsigned long)k);
    this->beaconrate[k] = beaconrate;
}

const char * BeaconRSU::getMyDemoData() const
{
    return this->myDemoData.c_str();
}

void BeaconRSU::setMyDemoData(const char * myDemoData)
{
    this->myDemoData = myDemoData;
}



//nonce
int BeaconRSU::getnonce() const
{
    return this->nonce;
}

void BeaconRSU::setnonce(int nonce)
{
    this->nonce = nonce;
}
//

//token
int BeaconRSU::gettoken() const
{
    return this->token;
}

void BeaconRSU::settoken(int token)
{
    this->token = token;
}
//

//fingerprint
void BeaconRSU::setfingerprint(int fingerprint)
{
    this->fingerprint = fingerprint;
}
int BeaconRSU::getfingerprint() const
{
    return this->fingerprint;
}
//

//linkagevalue
void BeaconRSU::setlinkagevalue(int linkagevalue)
{
    this->linkagevalue = linkagevalue;
}
int BeaconRSU::getlinkagevalue() const
{
    return this->linkagevalue;
}
//



const Coord& BeaconRSU::getSlotpos() const
{
    return this->slotpos;
}

void BeaconRSU::setSlotpos(const Coord& slotpos)
{
    this->slotpos = slotpos;
}

omnetpp::simtime_t BeaconRSU::getTimestamp() const
{
    return this->timestamp;
}

void BeaconRSU::setTimestamp(omnetpp::simtime_t timestamp)
{
    this->timestamp = timestamp;
}

class BeaconRSUDescriptor : public omnetpp::cClassDescriptor
{
  private:
    mutable const char **propertynames;
    enum FieldConstants {
        FIELD_RSUId,
        FIELD_position,
        FIELD_beaconrate,
        FIELD_myDemoData,
        FIELD_slotpos,
        FIELD_timestamp,
    };
  public:
    BeaconRSUDescriptor();
    virtual ~BeaconRSUDescriptor();

    virtual bool doesSupport(omnetpp::cObject *obj) const override;
    virtual const char **getPropertyNames() const override;
    virtual const char *getProperty(const char *propertyname) const override;
    virtual int getFieldCount() const override;
    virtual const char *getFieldName(int field) const override;
    virtual int findField(const char *fieldName) const override;
    virtual unsigned int getFieldTypeFlags(int field) const override;
    virtual const char *getFieldTypeString(int field) const override;
    virtual const char **getFieldPropertyNames(int field) const override;
    virtual const char *getFieldProperty(int field, const char *propertyname) const override;
    virtual int getFieldArraySize(void *object, int field) const override;

    virtual const char *getFieldDynamicTypeString(void *object, int field, int i) const override;
    virtual std::string getFieldValueAsString(void *object, int field, int i) const override;
    virtual bool setFieldValueAsString(void *object, int field, int i, const char *value) const override;

    virtual const char *getFieldStructName(int field) const override;
    virtual void *getFieldStructValuePointer(void *object, int field, int i) const override;
};

Register_ClassDescriptor(BeaconRSUDescriptor)

BeaconRSUDescriptor::BeaconRSUDescriptor() : omnetpp::cClassDescriptor(omnetpp::opp_typename(typeid(veins::BeaconRSU)), "veins::BaseFrame1609_4")
{
    propertynames = nullptr;
}

BeaconRSUDescriptor::~BeaconRSUDescriptor()
{
    delete[] propertynames;
}

bool BeaconRSUDescriptor::doesSupport(omnetpp::cObject *obj) const
{
    return dynamic_cast<BeaconRSU *>(obj)!=nullptr;
}

const char **BeaconRSUDescriptor::getPropertyNames() const
{
    if (!propertynames) {
        static const char *names[] = {  nullptr };
        omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
        const char **basenames = basedesc ? basedesc->getPropertyNames() : nullptr;
        propertynames = mergeLists(basenames, names);
    }
    return propertynames;
}

const char *BeaconRSUDescriptor::getProperty(const char *propertyname) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? basedesc->getProperty(propertyname) : nullptr;
}

int BeaconRSUDescriptor::getFieldCount() const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    return basedesc ? 6+basedesc->getFieldCount() : 6;
}

unsigned int BeaconRSUDescriptor::getFieldTypeFlags(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldTypeFlags(field);
        field -= basedesc->getFieldCount();
    }
    static unsigned int fieldTypeFlags[] = {
        FD_ISEDITABLE,    // FIELD_RSUId
        FD_ISARRAY,    // FIELD_position
        FD_ISARRAY | FD_ISEDITABLE,    // FIELD_beaconrate
        FD_ISEDITABLE,    // FIELD_myDemoData
        0,    // FIELD_slotpos
        0,    // FIELD_timestamp
    };
    return (field >= 0 && field < 6) ? fieldTypeFlags[field] : 0;
}

const char *BeaconRSUDescriptor::getFieldName(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldName(field);
        field -= basedesc->getFieldCount();
    }
    static const char *fieldNames[] = {
        "RSUId",
        "position",
        "beaconrate",
        "myDemoData",
        "slotpos",
        "timestamp",
    };
    return (field >= 0 && field < 6) ? fieldNames[field] : nullptr;
}

int BeaconRSUDescriptor::findField(const char *fieldName) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    int base = basedesc ? basedesc->getFieldCount() : 0;
    if (fieldName[0] == 'R' && strcmp(fieldName, "RSUId") == 0) return base+0;
    if (fieldName[0] == 'p' && strcmp(fieldName, "position") == 0) return base+1;
    if (fieldName[0] == 'b' && strcmp(fieldName, "beaconrate") == 0) return base+2;
    if (fieldName[0] == 'm' && strcmp(fieldName, "myDemoData") == 0) return base+3;
    if (fieldName[0] == 's' && strcmp(fieldName, "slotpos") == 0) return base+4;
    if (fieldName[0] == 't' && strcmp(fieldName, "timestamp") == 0) return base+5;
    return basedesc ? basedesc->findField(fieldName) : -1;
}

const char *BeaconRSUDescriptor::getFieldTypeString(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldTypeString(field);
        field -= basedesc->getFieldCount();
    }
    static const char *fieldTypeStrings[] = {
        "int",    // FIELD_RSUId
        "veins::Coord",    // FIELD_position
        "double",    // FIELD_beaconrate
        "string",    // FIELD_myDemoData
        "veins::Coord",    // FIELD_slotpos
        "omnetpp::simtime_t",    // FIELD_timestamp
    };
    return (field >= 0 && field < 6) ? fieldTypeStrings[field] : nullptr;
}

const char **BeaconRSUDescriptor::getFieldPropertyNames(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldPropertyNames(field);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

const char *BeaconRSUDescriptor::getFieldProperty(int field, const char *propertyname) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldProperty(field, propertyname);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    }
}

int BeaconRSUDescriptor::getFieldArraySize(void *object, int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldArraySize(object, field);
        field -= basedesc->getFieldCount();
    }
    BeaconRSU *pp = (BeaconRSU *)object; (void)pp;
    switch (field) {
        case FIELD_position: return 100;
        case FIELD_beaconrate: return 100;
        default: return 0;
    }
}

const char *BeaconRSUDescriptor::getFieldDynamicTypeString(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldDynamicTypeString(object,field,i);
        field -= basedesc->getFieldCount();
    }
    BeaconRSU *pp = (BeaconRSU *)object; (void)pp;
    switch (field) {
        default: return nullptr;
    }
}

std::string BeaconRSUDescriptor::getFieldValueAsString(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldValueAsString(object,field,i);
        field -= basedesc->getFieldCount();
    }
    BeaconRSU *pp = (BeaconRSU *)object; (void)pp;
    switch (field) {
        case FIELD_RSUId: return long2string(pp->getRSUId());
        case FIELD_position: {std::stringstream out; out << pp->getPosition(i); return out.str();}
        case FIELD_beaconrate: return double2string(pp->getBeaconrate(i));
        case FIELD_myDemoData: return oppstring2string(pp->getMyDemoData());
        case FIELD_slotpos: {std::stringstream out; out << pp->getSlotpos(); return out.str();}
        case FIELD_timestamp: return simtime2string(pp->getTimestamp());
        default: return "";
    }
}

bool BeaconRSUDescriptor::setFieldValueAsString(void *object, int field, int i, const char *value) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->setFieldValueAsString(object,field,i,value);
        field -= basedesc->getFieldCount();
    }
    BeaconRSU *pp = (BeaconRSU *)object; (void)pp;
    switch (field) {
        case FIELD_RSUId: pp->setRSUId(string2long(value)); return true;
        case FIELD_beaconrate: pp->setBeaconrate(i,string2double(value)); return true;
        case FIELD_myDemoData: pp->setMyDemoData((value)); return true;
        default: return false;
    }
}

const char *BeaconRSUDescriptor::getFieldStructName(int field) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldStructName(field);
        field -= basedesc->getFieldCount();
    }
    switch (field) {
        default: return nullptr;
    };
}

void *BeaconRSUDescriptor::getFieldStructValuePointer(void *object, int field, int i) const
{
    omnetpp::cClassDescriptor *basedesc = getBaseClassDescriptor();
    if (basedesc) {
        if (field < basedesc->getFieldCount())
            return basedesc->getFieldStructValuePointer(object, field, i);
        field -= basedesc->getFieldCount();
    }
    BeaconRSU *pp = (BeaconRSU *)object; (void)pp;
    switch (field) {
        case FIELD_position: return toVoidPtr(&pp->getPosition(i)); break;
        case FIELD_slotpos: return toVoidPtr(&pp->getSlotpos()); break;
        default: return nullptr;
    }
}

} // namespace veins

