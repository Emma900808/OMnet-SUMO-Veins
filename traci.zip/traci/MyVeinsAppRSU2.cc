//
// Copyright (C) 2016 David Eckhoff <david.eckhoff@fau.de>
//
// Documentation for these modules is at http://veins.car2x.org/
//
// SPDX-License-Identifier: GPL-2.0-or-later
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

#include "veins/modules/application/traci/MyVeinsAppRSU2.h"

using namespace veins;

Define_Module(veins::MyVeinsAppRSU2);

void MyVeinsAppRSU2::initialize(int stage)
{
    DemoBaseApplLayer::initialize(stage);
    if (stage == 0) {
        sendBeacon = new cMessage("send Beacon");

        hasReceivedAck = false;//
        // Initializing members and pointers of your application goes here
        EV << "Initializing " << par("appName").stringValue() << std::endl;
    }
    else if (stage == 1) {
        // Initializing members that require initialized other modules goes here
        if (sendBeacon->isScheduled()){
            cancelEvent(sendBeacon);
        }
        scheduleAt(simTime()+5,sendBeacon);
    }
}

void MyVeinsAppRSU2::finish()
{
    //DemoBaseApplLayer::finish();
    // statistics recording goes here
}

void MyVeinsAppRSU2::onBSM(DemoSafetyMessage* bsm)
{
    // Your application has received a beacon message from another car or RSU
    // code for handling the message goes here
}

void MyVeinsAppRSU2::onWSM(BaseFrame1609_4* wsm)
{
    // Your application has received a data message from another car or RSU
    // code for handling the message goes here, see TraciDemo11p.cc for examples
}

void MyVeinsAppRSU2::onWSA(DemoServiceAdvertisment* wsa)
{
    // Your application has received a service advertisement from another car or RSU
    // code for handling the message goes here, see TraciDemo11p.cc for examples
}

void MyVeinsAppRSU2::handleSelfMsg(cMessage* msg)
{
    //(msg == sendBeacon &&!hasReceivedAck)
    if (msg == sendBeacon){
        BeaconRSU* rsuBeacon = new BeaconRSU();
        rsuBeacon->setRSUId(this->getParentModule()->getIndex());
        rsuBeacon->setMyDemoData("RSU2 message!!!!!");
        BaseFrame1609_4* WSM = new BaseFrame1609_4();
        WSM->encapsulate(rsuBeacon);
        populateWSM(WSM);

        send(WSM,lowerLayerOut);
        EV<<"rsu2 send success"<<endl;
        if(simTime()<2000){
            scheduleAt(simTime()+1,sendBeacon);
        }
        return;
    }
    //DemoBaseApplLayer::handleSelfMsg(msg);
    // this method is for self messages (mostly timers)
    // it is important to call the DemoBaseApplLayer function for BSM and WSM transmission

}

void MyVeinsAppRSU2::handlePositionUpdate(cObject* obj)
{
    // DemoBaseApplLayer::handlePositionUpdate(obj);
    // the vehicle has moved. Code that reacts to new positions goes here.
    // member variables such as currentPosition and currentSpeed are updated in the parent class
}


void MyVeinsAppRSU2::handleLowerMsg(cMessage* msg)
{
    EV << "RSU2 received message!" << endl;

    BaseFrame1609_4* WSM = check_and_cast<BaseFrame1609_4*>(msg);
    cPacket* enc = WSM->getEncapsulatedPacket();
    BeaconRSU* bc = dynamic_cast<BeaconRSU*>(enc);

    if (bc) {
        EV << "Received message from vehicle! Content: " << bc->getMyDemoData() << endl;

        // ��� 瑼Ｘ閮��� "ACK from vehicle!"
        if (std::string(bc->getMyDemoData()) == "ACK from vehicle!") {
            EV << "RSU2 received ACK!" << endl;
            //EV << "RSU received ACK! Stopping broadcasts." << endl;
            //hasReceivedAck = true;  // ��� 閮�歇�� ACK
        }
    }
}
