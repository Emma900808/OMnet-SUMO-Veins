//
// Copyright (C) 2016 David Eckhoff <david.eckhoff@fau.de>
//
// Documentation for these modules is at http://veins.car2x.org/
//
// SPDX-License-Identifier: GPL-2.0-or-later
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//

#include "veins/modules/application/traci/MyVeinsAppCar.h"
#include <cstdlib> // for rand()
#include <ctime>   // for seeding random
#include <queue>
#include <cstring>
using namespace veins;

Define_Module(veins::MyVeinsAppCar);

void MyVeinsAppCar::initialize(int stage)
{
    DemoBaseApplLayer::initialize(stage);
    if (stage == 0) {
        // Initializing members and pointers of your application goes here
        EV << "Initializing " << par("appName").stringValue() << std::endl;
        std::srand(std::time(nullptr)); // Seed random number generator
        int a=INT_MIN;
    }
    else if (stage == 1) {
        // Initializing members that require initialized other modules goes here
        RSUIndex.setName("test");
        int a=INT_MIN;
    }
}

void MyVeinsAppCar::finish()
{
    //DemoBaseApplLayer::finish();
    // statistics recording goes here
}

void MyVeinsAppCar::onBSM(DemoSafetyMessage* bsm)
{
    // Your application has received a beacon message from another car or RSU
    // code for handling the message goes here
}

void MyVeinsAppCar::onWSM(BaseFrame1609_4* wsm)
{
    // Your application has received a data message from another car or RSU
    // code for handling the message goes here, see TraciDemo11p.cc for examples
}

void MyVeinsAppCar::onWSA(DemoServiceAdvertisment* wsa)
{
    // Your application has received a service advertisement from another car or RSU
    // code for handling the message goes here, see TraciDemo11p.cc for examples
}

void MyVeinsAppCar::handleSelfMsg(cMessage* msg)
{
   // DemoBaseApplLayer::handleSelfMsg(msg);
    // this method is for self messages (mostly timers)
    // it is important to call the DemoBaseApplLayer function for BSM and WSM transmission
}

void MyVeinsAppCar::handlePositionUpdate(cObject* obj)
{
    //DemoBaseApplLayer::handlePositionUpdate(obj);
    // the vehicle has moved. Code that reacts to new positions goes here.
    // member variables such as currentPosition and currentSpeed are updated in the parent class
}

void MyVeinsAppCar::handleLowerMsg(cMessage* msg)
{
    EV<<"receive message !!!"<<endl;
    BaseFrame1609_4*WSM = check_and_cast< BaseFrame1609_4*>(msg);  //get wsm from rsu
    cPacket* enc = WSM->getEncapsulatedPacket();      //get wsm inside data
    BeaconRSU* bc = dynamic_cast<BeaconRSU*>(enc);    //data transfer to BeaconRSU type


    if (!bc) {
         EV << "Error: Received packet is not a BeaconRSU!" << endl;
         return;
     }

    //!!!!!
    int rsuId = bc->getRSUId();  //get RSUID
    if (receivedRSUs.find(rsuId) != receivedRSUs.end()) {    //if is already pass the rsu
        EV << "Already received message from RSU " << rsuId << ". Ignoring." << endl;   //ignore
        return;  //the code will break here
    }
    receivedRSUs.insert(rsuId); // remind RSUID
    //!!!!

    //if(a!=bc->getRSUId()){
    //     RSUIndex.record(bc->getRSUId());
    //     a=bc->getRSUId();
    // }

    //if is not yet pass the rsu will go here
    EV<<"my message=  "<<bc->getMyDemoData()<<endl; //output data (now the type is string => "RSU message!!!!!" set in rsu code)
    EV<<"send message RSU id:  "<<bc->getRSUId()<<" Receive successfully!!!!!!!!"<<endl;  //out the rsuid and receive success
    EV<<"send nonce:  "<<bc->getnonce()<<" Receive successfully!!!!!!!!"<<endl;
    EV<<"send token:  "<<bc->gettoken()<<" Receive successfully!!!!!!!!"<<endl;
    tokenList.push(bc->gettoken());
    nonceList.push(bc->getnonce());
    EV<<"queue store token and nonce success"<<endl;

     //new resend to rsu
     BaseFrame1609_4* ackMsg = new BaseFrame1609_4();  //create a new message(packet) transfer to rsu
     BeaconRSU* ackData = new BeaconRSU();             //create a new message(data) transfer to rsu
     ackData->setRSUId(bc->getRSUId());           //set data rsuid
     ackData->setMyDemoData("ACK from vehicle!"); //set data string
     ackMsg->encapsulate(ackData); //use packet to encapsulate data
     populateWSM(ackMsg);  //set packet to wsm
     send(ackMsg, lowerLayerOut); // send packet to car (ACK
     EV << "Vehicle sent ACK to RSU!" << endl;  //output send ack success


     //rsu0
     if(bc->getRSUId()==0){
         EV << " Here is rsu0" << endl;
         ackData->setlinkagevalue(std::rand()); // Generate random nonce
         ackData->setfingerprint(std::rand()); // Generate random token
         EV<<"set linkagevalue:  "<<ackData->getlinkagevalue()<<" set successfully!!!!!!!!"<<endl;
         EV<<"set fingerprint:  "<<ackData->getfingerprint()<<" set successfully!!!!!!!!"<<endl;
         fingerprintList.push(ackData->getfingerprint());
         linkageList.push(ackData->getlinkagevalue());
         EV<<"queue store linkagevalue and fingerprint success"<<endl;
     }



     //rsu1
     if(bc->getRSUId()==1){
        EV << " Here is rsu1" << endl;
        if (tokenList.empty() || nonceList.empty() || linkageList.empty() || fingerprintList.empty()) {
               EV << "Error: Queue is empty, cannot retrieve data!" << endl;
               return;
         }
        token=tokenList.front();
        nonce=nonceList.front();
        linkage= linkageList.front();
        fingerprint= fingerprintList.front() ;

        EV<<"get nonce: "<< nonce   <<" success"<<endl;
        EV<<"get token: "<<   token  <<" success"<<endl;
        EV<<"get linkagevalue: "<<  linkage  <<" success"<<endl;
        EV<<"get fingerprint: "<<   fingerprint  <<" success"<<endl;
        tokenList.pop();
        nonceList.pop();
        linkageList.pop();
        fingerprintList.pop();
        EV<<"pop finish"<<endl;

       //
       EV<<"start zksnark"<<endl;
       bool verificationPassed = sendDataToZoKrates(fingerprint,fingerprint);
       if (verificationPassed) {
           EV << "[OMNeT++] ZoKrates VERIFY SUCCESS" << endl;
       } else {
           EV << "[OMNeT++] ZoKrates VERIFY FAIL" << endl;
       }
     }

}

bool MyVeinsAppCar::sendDataToZoKrates(int a, int b) {
    #ifdef _WIN32
        WSADATA wsaData;
        if (WSAStartup(MAKEWORD(2,2), &wsaData) != 0) {
            EV << "[OMNeT++] Winsock initialization failed." << endl;
            return false;
        }
    #endif

    EV << "[OMNeT++] Connecting to Python Server..." << endl;

    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock == -1) {
        EV << "[OMNeT++] Socket creation failed." << endl;
        return false;
    }

    struct sockaddr_in server;
    server.sin_addr.s_addr = inet_addr("127.0.0.1");
    server.sin_family = AF_INET;
    server.sin_port = htons(65432);

    if (connect(sock, (struct sockaddr*)&server, sizeof(server)) < 0) {
        EV << "[OMNeT++] Failed to connect to Python Server." << endl;
        closesocket(sock);
        return false;
    }

    EV << "[OMNeT++] Sending values to Python Server: " << a << " and " << b << endl;

    std::string message = std::to_string(a) + " " + std::to_string(b);
    ::send(sock, message.c_str(), static_cast<int>(message.size()), 0);
    EV << "[OMNeT++] Data sent to Python Server." << endl;

    char buffer[1024] = {0};
    int bytesReceived = recv(sock, buffer, sizeof(buffer), 0);

    if (bytesReceived > 0) {
        EV << "[OMNeT++] Received response from Python Server: " << buffer << endl;
    } else {
        EV << "[OMNeT++] No response received from Python Server." << endl;
        closesocket(sock);
        #ifdef _WIN32
            WSACleanup();
        #endif
        return false;
    }

    closesocket(sock);
    #ifdef _WIN32
        WSACleanup();
    #endif

    if (strncmp(buffer, "PASSED", 6) == 0) {
        EV << "[OMNeT++] Python Server verification PASSED." << endl;
        return true;
    } else {
        EV << "[OMNeT++] Python Server verification FAILED." << endl;
        return false;
    }
}
